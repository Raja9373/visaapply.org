---
title: "India to Canada Tourist Visa Guide (Visitor Visa)"
from: "IN"
to: "CA"
type: "tourist"
date: "2026-11-12"
fees: "CAD $100 + CAD $85 Biometrics"
docs: "Valid Passport, Bank Statements ($10,000+ CAD), Return Flight Itinerary, Travel Insurance, Cover Letter"
---

# India to Canada Tourist Visa (Visitor Visa) Complete Guide

Planning a trip from India to Canada? This comprehensive guide covers everything you need to successfully apply for a Canadian Visitor Visa (Temporary Resident Visa - TRV).

## 1. Overview & Eligibility
Citizens of India holding an ordinary passport require a TRV to enter Canada for tourism, visiting family, or short business trips. You must prove you will leave Canada at the end of your authorized stay.

## 2. Official Visa Fees
* **Application Processing Fee:** CAD $100 per person
* **Biometric Fee:** CAD $85 per person (mandatory for applicants aged 14-79)
* **Total Estimated Cost:** CAD $185 (~₹11,500 INR)

## 3. Required Document Checklist
1. **Valid Passport:** Must be valid for at least 6 months beyond your planned departure from Canada.
2. **Proof of Financial Support:** Recent bank statements for the last 4-6 months showing at least CAD $10,000 (~₹6 Lakhs INR) for personal maintenance.
3. **Travel Itinerary:** Flight reservations, hotel bookings, and a detailed day-by-day travel plan.
4. **Employment / Ties to Home Country:** Leave sanction letter, salary slips (last 3 months), tax returns (ITR for past 2 years), and business ownership proof if self-employed.
5. **Cover Letter:** Explaining the purpose of your visit and your itinerary.
6. **Medical & Police Clearance:** If requested by the visa officer.

## 4. Application Process (Step-by-Step)
1. **Create an IRCC Account:** Register online on the official Government of Canada Immigration portal.
2. **Complete Application Forms:** Fill out IMM 5257 and supporting questionnaires.
3. **Upload Documents:** Scan and upload all required PDFs (passport, financials, itinerary).
4. **Pay Fees Online:** Pay CAD $185 securely via credit card.
5. **Biometric Appointment:** Book and attend your biometrics collection at the nearest VFS Global center in India (New Delhi, Mumbai, Bengaluru, Chennai, etc.).
6. **Passport Submission:** Once approved, submit your physical passport for visa stamping.

## 5. Processing Times
Average processing time for Indian applicants ranges between **30 to 60 days**. Apply at least 3 months prior to your intended travel date.

## 6. Frequently Asked Questions (FAQ)
* **Can I work in Canada on a visitor visa?** No, unauthorized employment is strictly prohibited.
* **Can I extend my stay while in Canada?** Yes, you can apply for a visitor record extension at least 30 days before your status expires.