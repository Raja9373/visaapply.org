---
title: "United States to United Kingdom Standard Visitor Visa"
from: "US"
to: "UK"
type: "tourist"
date: "2026-11-12"
fees: "£115 (Standard 6 Months)"
docs: "Valid US Passport, Proof of Employment/Funds, Travel Itinerary"
---

# US to UK Standard Visitor Visa Guide

Traveling from the United States to the United Kingdom? US passport holders do not require a pre-arrival visa for tourist visits under 6 months, but green card holders and other nationalities residing in the US may require a Standard Visitor Visa.

## 1. Visa Fees & Options
* **6-Month Standard Visitor:** £115
* **2-Year Long-Term Visitor:** £400
* **5-Year Long-Term Visitor:** £771
* **10-Year Long-Term Visitor:** £963

## 2. Required Documents
* Valid Passport or US Green Card / US Visa stamp
* Proof of funds (bank statements)
* Accommodation and flight booking details
* Employer letter confirming leave of absence

## 3. Step-by-Step Application Process
1. Apply online via GOV.UK.
2. Pay visa fee and healthcare surcharge (if applicable).
3. Book biometrics appointment at a US CISAC or VFS center.
4. Mail or submit passport for vignette sticker.