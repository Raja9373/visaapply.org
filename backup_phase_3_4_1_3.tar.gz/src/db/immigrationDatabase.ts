import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import {
  REQUIREMENT_CLASSIFICATIONS,
  REQUIREMENT_CLASSIFICATION_META,
  THIRTY_SECTIONS_REGISTRY,
  SIX_LIFECYCLE_STAGES,
  TWENTY_TWO_SPECIAL_TOPICS_REGISTRY,
  EVIDENCE_STATUSES,
  QUALIFYING_OFFICIAL_EVIDENCE_STATUSES,
  INVALIDATING_EVIDENCE_STATUSES,
  normalizeEvidenceStatus,
  isQualifyingOfficialEvidence,
  isInvalidatingEvidenceStatus,
  isValidRequirementClassification,
  normalizeVisaDetailTo30Sections,
  denormalize30SectionsToLegacy13,
  sync30SectionsToLegacyDetails,
  syncLegacyDetailsTo30Sections,
  isSectionSubstantivelyPopulated,
  isTopicSubstantivelyPopulated,
  validateComprehensiveProfileHonesty,
  evaluateClaimIntegrity,
  createDefaultApplicantSpecialTopics,
  sanitizeVisaDetailsForPublic
} from '../types/visaComprehensiveProfile';
import type {
  RequirementClassification,
  EvidenceStatus,
  EvidenceVerificationStatus,
  VisaComprehensiveProfile,
  VisaApplicantSpecialTopics
} from '../types/visaComprehensiveProfile';

export {
  REQUIREMENT_CLASSIFICATIONS,
  REQUIREMENT_CLASSIFICATION_META,
  THIRTY_SECTIONS_REGISTRY,
  SIX_LIFECYCLE_STAGES,
  TWENTY_TWO_SPECIAL_TOPICS_REGISTRY,
  EVIDENCE_STATUSES,
  QUALIFYING_OFFICIAL_EVIDENCE_STATUSES,
  INVALIDATING_EVIDENCE_STATUSES,
  normalizeEvidenceStatus,
  isQualifyingOfficialEvidence,
  isInvalidatingEvidenceStatus,
  isValidRequirementClassification,
  normalizeVisaDetailTo30Sections,
  denormalize30SectionsToLegacy13,
  sync30SectionsToLegacyDetails,
  syncLegacyDetailsTo30Sections,
  isSectionSubstantivelyPopulated,
  isTopicSubstantivelyPopulated,
  validateComprehensiveProfileHonesty,
  evaluateClaimIntegrity,
  createDefaultApplicantSpecialTopics,
  sanitizeVisaDetailsForPublic
};
export type {
  RequirementClassification,
  EvidenceStatus,
  EvidenceVerificationStatus,
  VisaComprehensiveProfile,
  VisaApplicantSpecialTopics
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_DIR = path.join(process.cwd(), 'data_db');
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

const DB_PATH = path.join(DB_DIR, 'immigration_hub.db');

export const db = new Database(DB_PATH);

// Enable Write-Ahead Logging (WAL) for safe concurrent reads & writes
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');

/**
 * Additive, non-destructive Phase 3.1 schema migration for any SQLite Database instance.
 * Can be tested independently on a database copy before or alongside active DB usage.
 */
export function applyPhase31SqliteMigrations(targetDb: Database.Database = db) {
  targetDb.exec(`PRAGMA foreign_keys = ON;`);

  // 1. Ensure Phase 2.10.5 & Phase 3.2 evidence columns exist
  const evidenceCols = [
    { name: 'source_title', type: 'TEXT' },
    { name: 'issuing_authority', type: 'TEXT' },
    { name: 'publication_date', type: 'TEXT' },
    { name: 'access_date', type: 'TEXT' },
    { name: 'reviewer_notes', type: 'TEXT' },
    { name: 'excerpt', type: "TEXT DEFAULT ''" },
    { name: 'status', type: "TEXT DEFAULT 'NEEDS_REVIEW'" }
  ];
  for (const col of evidenceCols) {
    try {
      targetDb.exec(`ALTER TABLE visa_detail_evidence ADD COLUMN ${col.name} ${col.type};`);
    } catch {
      // Ignored if column already exists
    }
  }

  // 2. Phase 3.1: Add comprehensive_sections_json to visa_details
  try {
    targetDb.exec(`ALTER TABLE visa_details ADD COLUMN comprehensive_sections_json TEXT DEFAULT '{}';`);
  } catch {
    // Ignored if column already exists
  }

  // 3. Phase 3.1: Add 5-tier classification & nationality metadata to visa_detail_claims
  const claimCols = [
    { name: 'requirement_classification', type: "TEXT NOT NULL DEFAULT 'ADMIN_INSTRUCTION'" },
    { name: 'applicable_nationality', type: "TEXT NOT NULL DEFAULT 'ALL'" },
    { name: 'country_iso', type: "TEXT NOT NULL DEFAULT ''" },
    { name: 'visa_category', type: "TEXT NOT NULL DEFAULT ''" }
  ];
  for (const col of claimCols) {
    try {
      targetDb.exec(`ALTER TABLE visa_detail_claims ADD COLUMN ${col.name} ${col.type};`);
    } catch {
      // Ignored if column already exists
    }
  }

  // 4. Phase 3.1: Add indexes for claim classification and nationality queries
  targetDb.exec(`
    CREATE INDEX IF NOT EXISTS idx_claims_classification ON visa_detail_claims(program_id, requirement_classification);
    CREATE INDEX IF NOT EXISTS idx_claims_nationality ON visa_detail_claims(program_id, applicable_nationality);
  `);
}

/**
 * Initialize database schema
 */
export function initDatabaseSchema() {
    db.exec(`PRAGMA foreign_keys = ON;`);

    db.exec(`
    CREATE TABLE IF NOT EXISTS batch_state (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      current_batch_index INTEGER NOT NULL DEFAULT 1,
      total_batches INTEGER NOT NULL DEFAULT 10,
      batch_size INTEGER NOT NULL DEFAULT 25,
      processed_country_codes TEXT NOT NULL,
      pending_country_codes TEXT NOT NULL,
      completed_country_codes TEXT NOT NULL,
      failed_country_codes TEXT NOT NULL,
      last_batch_run_date TEXT NOT NULL,
      is_executing INTEGER NOT NULL DEFAULT 0,
      total_discovered_programs INTEGER NOT NULL DEFAULT 1494,
      available_verified_count INTEGER NOT NULL DEFAULT 27,
      not_available_confirmed_count INTEGER NOT NULL DEFAULT 7,
      awaiting_verification_count INTEGER NOT NULL DEFAULT 1459,
      needs_review_count INTEGER NOT NULL DEFAULT 0,
      temporarily_closed_count INTEGER NOT NULL DEFAULT 0,
      expired_count INTEGER NOT NULL DEFAULT 1,
      last_scheduled_execution TEXT NOT NULL,
      last_actual_execution TEXT NOT NULL,
      execution_start_timestamp TEXT NOT NULL,
      execution_end_timestamp TEXT NOT NULL,
      success_status INTEGER NOT NULL DEFAULT 1,
      batch_completion_status TEXT NOT NULL,
      next_scheduled_execution TEXT NOT NULL,
      retry_count INTEGER NOT NULL DEFAULT 0,
      max_retries INTEGER NOT NULL DEFAULT 3,
      auto_resume_on_missed INTEGER NOT NULL DEFAULT 1,
      last_error TEXT,
      audit_logs_json TEXT NOT NULL DEFAULT '[]',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS immigration_programs (
      id TEXT PRIMARY KEY,
      country_code TEXT NOT NULL,
      category TEXT NOT NULL,
      official_name TEXT NOT NULL,
      local_language_name TEXT,
      legal_basis TEXT NOT NULL,
      classification_type TEXT NOT NULL,
      eligibility TEXT NOT NULL,
      nationality_restrictions TEXT NOT NULL,
      age_requirements TEXT NOT NULL,
      education_requirements TEXT NOT NULL,
      work_experience_requirements TEXT NOT NULL,
      min_salary_or_income TEXT NOT NULL,
      investment_requirement TEXT NOT NULL,
      required_funds_and_proof TEXT NOT NULL,
      residency_duration TEXT NOT NULL,
      renewal_rules TEXT,
      pr_or_citizenship_transition TEXT,
      family_inclusion_rules TEXT,
      work_and_study_rights TEXT,
      restrictions_and_exceptions TEXT,
      required_documents_json TEXT NOT NULL,
      documents_and_formats TEXT,
      translation_attestation_requirements TEXT,
      application_procedure TEXT NOT NULL,
      government_fees TEXT NOT NULL,
      processing_time TEXT NOT NULL,
      apply_from TEXT,
      official_application_url TEXT NOT NULL,
      official_information_url TEXT NOT NULL,
      source_authority TEXT NOT NULL,
      source_last_updated TEXT NOT NULL,
      last_checked_date TEXT NOT NULL,
      verification_evidence TEXT NOT NULL,
      verification_status TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS changelog_entries (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      country_code TEXT NOT NULL,
      country_name TEXT NOT NULL,
      change_type TEXT NOT NULL,
      title TEXT NOT NULL,
      old_value TEXT NOT NULL,
      new_value TEXT NOT NULL,
      source_url TEXT NOT NULL,
      auto_blog_slug TEXT NOT NULL,
      email_notified TEXT NOT NULL,
      verified_by TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cron_execution_logs (
      id TEXT PRIMARY KEY,
      timestamp TEXT NOT NULL,
      cron_name TEXT NOT NULL,
      http_method TEXT NOT NULL,
      target_countries TEXT NOT NULL,
      status TEXT NOT NULL,
      checked_count INTEGER NOT NULL,
      updates_found INTEGER NOT NULL,
      log_message TEXT NOT NULL,
      execution_duration_ms INTEGER NOT NULL,
      missed_run_resumed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_prog_country ON immigration_programs(country_code);
    CREATE INDEX IF NOT EXISTS idx_prog_status ON immigration_programs(verification_status);
    CREATE INDEX IF NOT EXISTS idx_changelog_date ON changelog_entries(date);
    CREATE INDEX IF NOT EXISTS idx_cron_time ON cron_execution_logs(timestamp);

    CREATE TABLE IF NOT EXISTS visa_details (
      id TEXT PRIMARY KEY,
      program_id TEXT NOT NULL REFERENCES immigration_programs(id),
      country_overview_json TEXT,
      visa_overview_json TEXT,
      eligibility_json TEXT,
      financial_json TEXT,
      document_checklist_json TEXT,
      application_fields_json TEXT,
      application_steps_json TEXT,
      interview_prep_json TEXT,
      embassy_directory_json TEXT,
      refusal_appeal_json TEXT,
      after_approval_json TEXT,
      cost_calculator_json TEXT,
      faq_json TEXT,
      legal_evidence_json TEXT,
      last_updated TEXT,
      verification_status TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_visa_details_program_id ON visa_details(program_id);

    CREATE TABLE IF NOT EXISTS visa_detail_claims (
      id TEXT PRIMARY KEY,
      program_id TEXT NOT NULL REFERENCES immigration_programs(id),
      section TEXT NOT NULL,
      description TEXT NOT NULL,
      value TEXT,
      unit TEXT,
      status TEXT NOT NULL DEFAULT 'NEEDS_EVIDENCE',
      reviewer TEXT,
      review_timestamp TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_claims_program ON visa_detail_claims(program_id);

    CREATE TABLE IF NOT EXISTS visa_detail_evidence (
      id TEXT PRIMARY KEY,
      claim_id TEXT NOT NULL REFERENCES visa_detail_claims(id),
      source_url TEXT NOT NULL,
      legal_instrument TEXT,
      effective_date TEXT,
      last_checked_date TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_evidence_claim ON visa_detail_evidence(claim_id);

    CREATE TABLE IF NOT EXISTS visa_detail_versions (
      id TEXT PRIMARY KEY,
      program_id TEXT NOT NULL REFERENCES immigration_programs(id),
      data_json TEXT NOT NULL,
      editor_id TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      change_reason TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_versions_program ON visa_detail_versions(program_id);
  `);

  applyPhase31SqliteMigrations(db);
}

initDatabaseSchema();

// Helper statement getters
export function getBatchStateFromDb() {
  try {
    const row = db.prepare('SELECT * FROM batch_state WHERE id = 1').get() as any;
    if (!row) return null;
    return {
      currentBatchIndex: row.current_batch_index,
      totalBatches: row.total_batches,
      batchSize: row.batch_size,
      processedCountryCodes: JSON.parse(row.processed_country_codes || '[]'),
      pendingCountryCodes: JSON.parse(row.pending_country_codes || '[]'),
      completedCountryCodes: JSON.parse(row.completed_country_codes || '[]'),
      failedCountryCodes: JSON.parse(row.failed_country_codes || '[]'),
      lastBatchRunDate: row.last_batch_run_date,
      isExecuting: Boolean(row.is_executing),
      totalDiscoveredPrograms: row.total_discovered_programs,
      availableVerifiedCount: row.available_verified_count,
      notAvailableConfirmedCount: row.not_available_confirmed_count,
      awaitingVerificationCount: row.awaiting_verification_count,
      needsReviewCount: row.needs_review_count,
      temporarilyClosedCount: row.temporarily_closed_count,
      expiredCount: row.expired_count,
      lastScheduledExecution: row.last_scheduled_execution,
      lastActualExecution: row.last_actual_execution,
      executionStartTimestamp: row.execution_start_timestamp,
      executionEndTimestamp: row.execution_end_timestamp,
      successStatus: Boolean(row.success_status),
      batchCompletionStatus: row.batch_completion_status,
      nextScheduledExecution: row.next_scheduled_execution,
      retryAndMissedRunHandling: {
        retryCount: row.retry_count,
        maxRetries: row.max_retries,
        autoResumeOnMissed: Boolean(row.auto_resume_on_missed),
        lastError: row.last_error
      },
      auditLogs: JSON.parse(row.audit_logs_json || '[]')
    };
  } catch (e) {
    return null;
  }
}

export function saveBatchStateToDb(state: any) {
  const stmt = db.prepare(`
    INSERT INTO batch_state (
      id, current_batch_index, total_batches, batch_size,
      processed_country_codes, pending_country_codes, completed_country_codes, failed_country_codes,
      last_batch_run_date, is_executing, total_discovered_programs,
      available_verified_count, not_available_confirmed_count, awaiting_verification_count,
      needs_review_count, temporarily_closed_count, expired_count,
      last_scheduled_execution, last_actual_execution, execution_start_timestamp, execution_end_timestamp,
      success_status, batch_completion_status, next_scheduled_execution,
      retry_count, max_retries, auto_resume_on_missed, last_error, audit_logs_json, updated_at
    ) VALUES (
      1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
    ON CONFLICT(id) DO UPDATE SET
      current_batch_index = excluded.current_batch_index,
      total_batches = excluded.total_batches,
      batch_size = excluded.batch_size,
      processed_country_codes = excluded.processed_country_codes,
      pending_country_codes = excluded.pending_country_codes,
      completed_country_codes = excluded.completed_country_codes,
      failed_country_codes = excluded.failed_country_codes,
      last_batch_run_date = excluded.last_batch_run_date,
      is_executing = excluded.is_executing,
      total_discovered_programs = excluded.total_discovered_programs,
      available_verified_count = excluded.available_verified_count,
      not_available_confirmed_count = excluded.not_available_confirmed_count,
      awaiting_verification_count = excluded.awaiting_verification_count,
      needs_review_count = excluded.needs_review_count,
      temporarily_closed_count = excluded.temporarily_closed_count,
      expired_count = excluded.expired_count,
      last_scheduled_execution = excluded.last_scheduled_execution,
      last_actual_execution = excluded.last_actual_execution,
      execution_start_timestamp = excluded.execution_start_timestamp,
      execution_end_timestamp = excluded.execution_end_timestamp,
      success_status = excluded.success_status,
      batch_completion_status = excluded.batch_completion_status,
      next_scheduled_execution = excluded.next_scheduled_execution,
      retry_count = excluded.retry_count,
      max_retries = excluded.max_retries,
      auto_resume_on_missed = excluded.auto_resume_on_missed,
      last_error = excluded.last_error,
      audit_logs_json = excluded.audit_logs_json,
      updated_at = excluded.updated_at
  `);

  const nowStr = new Date().toISOString();
  stmt.run(
    state.currentBatchIndex || 1,
    state.totalBatches || 10,
    state.batchSize || 25,
    JSON.stringify(state.processedCountryCodes || []),
    JSON.stringify(state.pendingCountryCodes || []),
    JSON.stringify(state.completedCountryCodes || []),
    JSON.stringify(state.failedCountryCodes || []),
    state.lastBatchRunDate || nowStr.split('T')[0],
    state.isExecuting ? 1 : 0,
    state.totalDiscoveredPrograms || 1494,
    state.availableVerifiedCount || 27,
    state.notAvailableConfirmedCount || 7,
    state.awaitingVerificationCount || 1459,
    state.needsReviewCount || 0,
    state.temporarilyClosedCount || 0,
    state.expiredCount || 1,
    state.lastScheduledExecution || nowStr,
    state.lastActualExecution || nowStr,
    state.executionStartTimestamp || nowStr,
    state.executionEndTimestamp || nowStr,
    state.successStatus !== false ? 1 : 0,
    state.batchCompletionStatus || 'Active',
    state.nextScheduledExecution || nowStr,
    state.retryAndMissedRunHandling?.retryCount || 0,
    state.retryAndMissedRunHandling?.maxRetries || 3,
    state.retryAndMissedRunHandling?.autoResumeOnMissed !== false ? 1 : 0,
    state.retryAndMissedRunHandling?.lastError || null,
    JSON.stringify(state.auditLogs || []),
    nowStr
  );
}

export function saveChangelogEntryToDb(entry: any) {
  const stmt = db.prepare(`
    INSERT INTO changelog_entries (
      id, date, country_code, country_name, change_type, title,
      old_value, new_value, source_url, auto_blog_slug, email_notified, verified_by, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      date = excluded.date,
      change_type = excluded.change_type,
      title = excluded.title,
      old_value = excluded.old_value,
      new_value = excluded.new_value,
      source_url = excluded.source_url,
      auto_blog_slug = excluded.auto_blog_slug,
      email_notified = excluded.email_notified,
      verified_by = excluded.verified_by
  `);

  stmt.run(
    entry.id,
    entry.date,
    entry.countryCode,
    entry.countryName,
    entry.changeType,
    entry.title,
    entry.oldValue,
    entry.newValue,
    entry.sourceUrl,
    entry.autoBlogSlug,
    entry.emailNotified,
    entry.verifiedBy,
    new Date().toISOString()
  );
}

export function getChangelogFromDb(): any[] {
  try {
    const rows = db.prepare('SELECT * FROM changelog_entries ORDER BY date DESC, created_at DESC').all() as any[];
    return rows.map((r) => ({
      id: r.id,
      date: r.date,
      countryCode: r.country_code,
      countryName: r.country_name,
      changeType: r.change_type,
      title: r.title,
      oldValue: r.old_value,
      newValue: r.new_value,
      sourceUrl: r.source_url,
      autoBlogSlug: r.auto_blog_slug,
      emailNotified: r.email_notified,
      verifiedBy: r.verified_by
    }));
  } catch (e) {
    return [];
  }
}

export function logCronExecutionToDb(log: {
  cronName: string;
  httpMethod: string;
  targetCountries: string[];
  status: string;
  checkedCount: number;
  updatesFound: number;
  logMessage: string;
  executionDurationMs: number;
  missedRunResumed?: boolean;
}) {
  const stmt = db.prepare(`
    INSERT INTO cron_execution_logs (
      id, timestamp, cron_name, http_method, target_countries, status,
      checked_count, updates_found, log_message, execution_duration_ms, missed_run_resumed, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const id = `cron-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const nowStr = new Date().toISOString();

  stmt.run(
    id,
    nowStr,
    log.cronName,
    log.httpMethod,
    JSON.stringify(log.targetCountries || []),
    log.status,
    log.checkedCount,
    log.updatesFound,
    log.logMessage,
    log.executionDurationMs,
    log.missedRunResumed ? 1 : 0,
    nowStr
  );
}

export function getCronExecutionLogsFromDb(limit: number = 20): any[] {
  try {
    const rows = db.prepare('SELECT * FROM cron_execution_logs ORDER BY timestamp DESC LIMIT ?').all(limit) as any[];
    return rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      cronName: r.cron_name,
      httpMethod: r.http_method,
      targetCountries: JSON.parse(r.target_countries || '[]'),
      status: r.status,
      checkedCount: r.checked_count,
      updatesFound: r.updates_found,
      logMessage: r.log_message,
      executionDurationMs: r.execution_duration_ms,
      missedRunResumed: Boolean(r.missed_run_resumed)
    }));
  } catch (e) {
    return [];
  }
}

function mapSqliteVisaDetailRow(row: any) {
  let rawComp: any = null;
  try {
    const parsedComp = JSON.parse(row.comprehensive_sections_json || '{}');
    if (parsedComp && parsedComp.sections) {
      rawComp = parsedComp;
    }
  } catch {
    rawComp = null;
  }

  const baseRecord: any = {
    id: row.id,
    programId: row.program_id,
    countryOverview: JSON.parse(row.country_overview_json || '{}'),
    visaOverview: JSON.parse(row.visa_overview_json || '{}'),
    eligibility: JSON.parse(row.eligibility_json || '{}'),
    financial: JSON.parse(row.financial_json || '{}'),
    documentChecklist: JSON.parse(row.document_checklist_json || '[]'),
    applicationFields: JSON.parse(row.application_fields_json || '[]'),
    applicationSteps: JSON.parse(row.application_steps_json || '[]'),
    interviewPrep: JSON.parse(row.interview_prep_json || '{}'),
    embassyDirectory: JSON.parse(row.embassy_directory_json || '[]'),
    refusalAppeal: JSON.parse(row.refusal_appeal_json || '{}'),
    afterApproval: JSON.parse(row.after_approval_json || '{}'),
    costCalculator: JSON.parse(row.cost_calculator_json || '{}'),
    faq: JSON.parse(row.faq_json || '[]'),
    legalEvidence: JSON.parse(row.legal_evidence_json || '[]'),
    lastUpdated: row.last_updated,
    verificationStatus: row.verification_status
  };

  baseRecord.comprehensiveSections = normalizeVisaDetailTo30Sections({
    ...baseRecord,
    comprehensiveSections: rawComp
  });

  return baseRecord;
}

export function getVisaDetails(programId: string): any | null {
  try {
    const row = db.prepare('SELECT * FROM visa_details WHERE program_id = ?').get(programId) as any;
    if (!row) return null;
    return mapSqliteVisaDetailRow(row);
  } catch (e) {
    return null;
  }
}

export function getPaginatedVisaDetails(page: number, limit: number, search: string = '', status: string = '', category: string = ''): { data: any[], total: number } {
  try {
    const offset = (page - 1) * limit;
    const filters = [];
    const params = [];
    
    if (search) {
      filters.push('(id LIKE ? OR program_id LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }
    if (status) {
      filters.push('verification_status = ?');
      params.push(status);
    }
    if (category) {
      // Reserved for category joins
    }
    
    const whereClause = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
    
    const totalRow = db.prepare(`SELECT COUNT(*) as count FROM visa_details ${whereClause}`).get(...params) as any;
    const total = totalRow.count;
    
    const rows = db.prepare(`
      SELECT * FROM visa_details 
      ${whereClause} 
      ORDER BY id 
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset) as any[];

    return {
      total,
      data: rows.map((row) => mapSqliteVisaDetailRow(row))
    };
  } catch (e) {
    return { data: [], total: 0 };
  }
}

export function saveVisaDetails(details: any) {
  const lastUpdated = details.lastUpdated || new Date().toISOString();
  const verificationStatus = details.verificationStatus || 'VERIFIED';
  const normalizedComp = normalizeVisaDetailTo30Sections({
    ...details,
    lastUpdated,
    verificationStatus
  });

  const stmt = db.prepare(`
    INSERT INTO visa_details (
      id, program_id, country_overview_json, visa_overview_json, eligibility_json,
      financial_json, document_checklist_json, application_fields_json,
      application_steps_json, interview_prep_json, embassy_directory_json,
      refusal_appeal_json, after_approval_json, cost_calculator_json,
      faq_json, legal_evidence_json, comprehensive_sections_json, last_updated, verification_status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      country_overview_json = excluded.country_overview_json,
      visa_overview_json = excluded.visa_overview_json,
      eligibility_json = excluded.eligibility_json,
      financial_json = excluded.financial_json,
      document_checklist_json = excluded.document_checklist_json,
      application_fields_json = excluded.application_fields_json,
      application_steps_json = excluded.application_steps_json,
      interview_prep_json = excluded.interview_prep_json,
      embassy_directory_json = excluded.embassy_directory_json,
      refusal_appeal_json = excluded.refusal_appeal_json,
      after_approval_json = excluded.after_approval_json,
      cost_calculator_json = excluded.cost_calculator_json,
      faq_json = excluded.faq_json,
      legal_evidence_json = excluded.legal_evidence_json,
      comprehensive_sections_json = excluded.comprehensive_sections_json,
      last_updated = excluded.last_updated,
      verification_status = excluded.verification_status
  `);
  const recordId =
    details.id && (!details.id.startsWith('vd-') || details.id === `vd-${details.programId}`)
      ? details.id
      : `vd-${details.programId}`;
  stmt.run(
    recordId,
    details.programId,
    JSON.stringify(details.countryOverview || {}),
    JSON.stringify(details.visaOverview || {}),
    JSON.stringify(details.eligibility || {}),
    JSON.stringify(details.financial || {}),
    JSON.stringify(details.documentChecklist || []),
    JSON.stringify(details.applicationFields || []),
    JSON.stringify(details.applicationSteps || []),
    JSON.stringify(details.interviewPrep || {}),
    JSON.stringify(details.embassyDirectory || []),
    JSON.stringify(details.refusalAppeal || {}),
    JSON.stringify(details.afterApproval || {}),
    JSON.stringify(details.costCalculator || {}),
    JSON.stringify(details.faq || []),
    JSON.stringify(details.legalEvidence || []),
    JSON.stringify(normalizedComp),
    lastUpdated,
    verificationStatus
  );
}

export function getDashboardStats() {
  try {
    const stats = db.prepare(`
      SELECT
          COUNT(*) as total,
          SUM(CASE WHEN verification_status = 'DRAFT' THEN 1 ELSE 0 END) as draft,
          SUM(CASE WHEN verification_status = 'NEEDS_EVIDENCE' THEN 1 ELSE 0 END) as needs_evidence,
          SUM(CASE WHEN verification_status = 'UNDER_REVIEW' THEN 1 ELSE 0 END) as under_review,
          SUM(CASE WHEN verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified,
          SUM(CASE WHEN verification_status = 'APPROVED' THEN 1 ELSE 0 END) as approved,
          SUM(CASE WHEN verification_status = 'PUBLISHED' THEN 1 ELSE 0 END) as published,
          SUM(CASE WHEN verification_status = 'UPDATE_REQUIRED' THEN 1 ELSE 0 END) as update_required,
          SUM(CASE WHEN verification_status = 'EXPIRED' THEN 1 ELSE 0 END) as expired,
          SUM(CASE WHEN verification_status = 'REJECTED' THEN 1 ELSE 0 END) as rejected,
          SUM(CASE WHEN verification_status = 'QUARANTINED' THEN 1 ELSE 0 END) as quarantined
      FROM visa_details;
    `).get() as any;

    const claimsStats = db.prepare(`
      SELECT 
        COUNT(DISTINCT c.id) as totalClaims,
        SUM(CASE WHEN e.id IS NULL THEN 1 ELSE 0 END) as claimsWithoutEvidence
      FROM visa_detail_claims c
      LEFT JOIN visa_detail_evidence e ON c.id = e.claim_id
    `).get() as any;

    return { ...stats, ...claimsStats };
  } catch (e) {
    return null;
  }
}

export function updateVisaStatus(programId: string, status: string) {
  const stmt = db.prepare(`UPDATE visa_details SET verification_status = ? WHERE program_id = ?`);
  stmt.run(status, programId);
}

export function restoreVersion(versionId: string, editorId: string = 'admin') {
  const version = db.prepare('SELECT * FROM visa_detail_versions WHERE id = ?').get(versionId) as any;
  if (!version) throw new Error('Version not found');
  
  const parsed = JSON.parse(version.data_json);
  const details = parsed.details || parsed;
  const programId = version.program_id;

  const tx = db.transaction(() => {
    saveVisaDetails({ ...details, programId });

    if (Array.isArray(parsed.claims)) {
      // Clear current claims/evidence for this program before restoring exact snapshot state
      const existingClaims = db.prepare('SELECT id FROM visa_detail_claims WHERE program_id = ?').all(programId) as any[];
      for (const ec of existingClaims) {
        db.prepare('DELETE FROM visa_detail_evidence WHERE claim_id = ?').run(ec.id);
      }
      db.prepare('DELETE FROM visa_detail_claims WHERE program_id = ?').run(programId);

      for (const c of parsed.claims) {
        saveVisaClaim({ ...c, programId });
        if (Array.isArray(c.evidence)) {
          for (const ev of c.evidence) {
            saveVisaEvidence({ ...ev, claimId: c.id }, { skipReconcile: true });
          }
        }
      }
    }

    // Create a new version for the restoration event (never erases history)
    const newVersionId = `ver-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    saveVisaVersion({
      id: newVersionId,
      programId,
      data: parsed,
      editorId,
      timestamp: new Date().toISOString(),
      changeReason: `Restored from version ${versionId} (${version.change_reason || 'Previous state'})`
    });

    return { success: true, restoredVersionId: versionId, newVersionId };
  });

  return tx();
}

// --- Claims, Evidence, Versions ---

export function getVisaClaims(programId: string): any[] {
  const rows = db.prepare('SELECT * FROM visa_detail_claims WHERE program_id = ? ORDER BY section ASC, description ASC').all(programId) as any[];
  return rows.map(r => ({
    id: r.id,
    programId: r.program_id,
    section: r.section,
    description: r.description,
    value: r.value,
    unit: r.unit,
    status: r.status,
    reviewer: r.reviewer,
    reviewTimestamp: r.review_timestamp,
    requirementClassification: isValidRequirementClassification(r.requirement_classification)
      ? r.requirement_classification
      : 'ADMIN_INSTRUCTION',
    applicableNationality: r.applicable_nationality || 'ALL',
    countryIso: r.country_iso || '',
    visaCategory: r.visa_category || ''
  }));
}

export function getVisaClaimsWithEvidence(programId: string, targetNationality?: string): any[] {
  const claims = getVisaClaims(programId);
  let progRow: any = null;
  try {
    progRow = db
      .prepare('SELECT country_code, category FROM immigration_programs WHERE id = ?')
      .get(programId) as any;
  } catch {
    progRow = null;
  }

  return claims.map(c => {
    const evidence = getVisaEvidence(c.id);
    const claimWithEv = { ...c, evidence };
    const integrity = evaluateClaimIntegrity(claimWithEv, {
      expectedCountryIso: progRow?.country_code || (programId || '').split('-')[0] || '',
      expectedVisaCategory: progRow?.category || '',
      targetNationality
    });
    return {
      ...claimWithEv,
      staleOrMissingEvidence: integrity.staleOrMissingEvidence,
      canPresentAsVerified: integrity.canPresentAsVerified,
      warnings: integrity.warnings,
      integrity
    };
  });
}

export function getVisaClaimById(claimId: string): any | null {
  const r = db.prepare('SELECT * FROM visa_detail_claims WHERE id = ?').get(claimId) as any;
  if (!r) return null;
  return {
    id: r.id,
    programId: r.program_id,
    section: r.section,
    description: r.description,
    value: r.value,
    unit: r.unit,
    status: r.status,
    reviewer: r.reviewer,
    reviewTimestamp: r.review_timestamp,
    requirementClassification: isValidRequirementClassification(r.requirement_classification)
      ? r.requirement_classification
      : 'ADMIN_INSTRUCTION',
    applicableNationality: r.applicable_nationality || 'ALL',
    countryIso: r.country_iso || '',
    visaCategory: r.visa_category || ''
  };
}

export function reconcileClaimVerificationAfterEvidenceChange(
  claimId: string,
  reasonTrigger: string
): {
  downgraded: boolean;
  previousStatus?: string;
  newStatus?: string;
  claimId: string;
  programId?: string;
  versionId?: string;
} {
  const claimRow = db.prepare('SELECT * FROM visa_detail_claims WHERE id = ?').get(claimId) as any;
  if (!claimRow) return { downgraded: false, claimId };

  const currentEv = getVisaEvidence(claimId);
  const integrity = evaluateClaimIntegrity({ ...claimRow, evidence: currentEv });

  if (claimRow.status === 'VERIFIED' && !integrity.hasQualifyingOfficialEvidence) {
    const tx = db.transaction(() => {
      const nowIso = new Date().toISOString();
      db.prepare('UPDATE visa_detail_claims SET status = ?, review_timestamp = ? WHERE id = ?').run(
        'NEEDS_EVIDENCE',
        nowIso,
        claimId
      );

      const programId = claimRow.program_id;
      const details = getVisaDetails(programId);
      const claimsSnapshot = getVisaClaimsWithEvidence(programId);
      const versionId = `ver-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      saveVisaVersion({
        id: versionId,
        programId,
        data: { details, claims: claimsSnapshot },
        editorId: 'system-integrity-guard',
        timestamp: nowIso,
        changeReason: `Auto-downgraded claim ${claimId} from VERIFIED to NEEDS_EVIDENCE (${reasonTrigger})`
      });

      return {
        downgraded: true,
        previousStatus: 'VERIFIED',
        newStatus: 'NEEDS_EVIDENCE',
        claimId,
        programId,
        versionId
      };
    });

    return tx();
  }

  return {
    downgraded: false,
    previousStatus: claimRow.status,
    newStatus: claimRow.status,
    claimId,
    programId: claimRow.program_id
  };
}

export function saveVisaClaim(claim: any) {
  const rawClassification = claim.requirementClassification || claim.requirement_classification;
  const requirementClassification: RequirementClassification = isValidRequirementClassification(rawClassification)
    ? rawClassification
    : 'ADMIN_INSTRUCTION';
  const applicableNationality = String(claim.applicableNationality || claim.applicable_nationality || 'ALL').trim() || 'ALL';
  const countryIso = String(claim.countryIso ?? claim.country_iso ?? '').trim();
  const visaCategory = String(claim.visaCategory ?? claim.visa_category ?? '').trim();

  const stmt = db.prepare(`
    INSERT INTO visa_detail_claims (
      id, program_id, section, description, value, unit, status, reviewer, review_timestamp,
      requirement_classification, applicable_nationality, country_iso, visa_category
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      section = excluded.section,
      description = excluded.description,
      value = excluded.value,
      unit = excluded.unit,
      status = excluded.status,
      reviewer = excluded.reviewer,
      review_timestamp = excluded.review_timestamp,
      requirement_classification = excluded.requirement_classification,
      applicable_nationality = excluded.applicable_nationality,
      country_iso = excluded.country_iso,
      visa_category = excluded.visa_category
  `);
  stmt.run(
    claim.id,
    claim.programId || claim.program_id,
    claim.section,
    claim.description,
    claim.value || '',
    claim.unit || '',
    claim.status || 'NEEDS_EVIDENCE',
    claim.reviewer || 'admin',
    claim.reviewTimestamp || claim.review_timestamp || new Date().toISOString(),
    requirementClassification,
    applicableNationality,
    countryIso,
    visaCategory
  );
}

export function deleteVisaClaim(claimId: string) {
  db.prepare('DELETE FROM visa_detail_evidence WHERE claim_id = ?').run(claimId);
  db.prepare('DELETE FROM visa_detail_claims WHERE id = ?').run(claimId);
}

export function getVisaEvidence(claimId: string): any[] {
  const rows = db.prepare('SELECT * FROM visa_detail_evidence WHERE claim_id = ?').all(claimId) as any[];
  return rows.map(r => ({
    id: r.id,
    claimId: r.claim_id,
    sourceUrl: r.source_url,
    legalInstrument: r.legal_instrument,
    effectiveDate: r.effective_date,
    lastCheckedDate: r.last_checked_date,
    sourceTitle: r.source_title || '',
    issuingAuthority: r.issuing_authority || '',
    publicationDate: r.publication_date || '',
    accessDate: r.access_date || r.last_checked_date || '',
    reviewerNotes: r.reviewer_notes || '',
    excerpt: r.excerpt || '',
    rawStatus: r.status || 'NEEDS_REVIEW',
    status: normalizeEvidenceStatus(r.status)
  }));
}

export function saveVisaEvidence(
  evidence: any,
  options?: { skipReconcile?: boolean }
): { downgradedClaim?: boolean; newClaimStatus?: string; versionId?: string } {
  const normalizedStatus = normalizeEvidenceStatus(evidence.status);
  const claimId = evidence.claimId || evidence.claim_id;
  const stmt = db.prepare(`
    INSERT INTO visa_detail_evidence (
      id, claim_id, source_url, legal_instrument, effective_date, last_checked_date,
      source_title, issuing_authority, publication_date, access_date, reviewer_notes, excerpt, status
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      source_url = excluded.source_url,
      legal_instrument = excluded.legal_instrument,
      effective_date = excluded.effective_date,
      last_checked_date = excluded.last_checked_date,
      source_title = excluded.source_title,
      issuing_authority = excluded.issuing_authority,
      publication_date = excluded.publication_date,
      access_date = excluded.access_date,
      reviewer_notes = excluded.reviewer_notes,
      excerpt = excluded.excerpt,
      status = excluded.status
  `);
  stmt.run(
    evidence.id,
    claimId,
    evidence.sourceUrl || evidence.source_url || '',
    evidence.legalInstrument || evidence.legal_instrument || '',
    evidence.effectiveDate || evidence.effective_date || '',
    evidence.lastCheckedDate || evidence.last_checked_date || new Date().toISOString().split('T')[0],
    evidence.sourceTitle || evidence.source_title || '',
    evidence.issuingAuthority || evidence.issuing_authority || '',
    evidence.publicationDate || evidence.publication_date || '',
    evidence.accessDate || evidence.access_date || evidence.lastCheckedDate || evidence.last_checked_date || new Date().toISOString().split('T')[0],
    evidence.reviewerNotes || evidence.reviewer_notes || '',
    evidence.excerpt || '',
    normalizedStatus
  );

  if (!options?.skipReconcile && claimId) {
    const rec = reconcileClaimVerificationAfterEvidenceChange(
      claimId,
      `Evidence ${evidence.id} status set to ${normalizedStatus}`
    );
    return {
      downgradedClaim: rec.downgraded,
      newClaimStatus: rec.newStatus,
      versionId: rec.versionId
    };
  }
  return {};
}

export function deleteVisaEvidence(evidenceId: string): {
  downgradedClaim?: boolean;
  newClaimStatus?: string;
  claimId?: string;
  versionId?: string;
} {
  const evRow = db
    .prepare('SELECT claim_id FROM visa_detail_evidence WHERE id = ?')
    .get(evidenceId) as any;
  db.prepare('DELETE FROM visa_detail_evidence WHERE id = ?').run(evidenceId);
  if (evRow?.claim_id) {
    const rec = reconcileClaimVerificationAfterEvidenceChange(
      evRow.claim_id,
      `Evidence ${evidenceId} deleted`
    );
    return {
      downgradedClaim: rec.downgraded,
      newClaimStatus: rec.newStatus,
      claimId: evRow.claim_id,
      versionId: rec.versionId
    };
  }
  return {};
}

export function getVisaVersions(programId: string): any[] {
  const rows = db.prepare('SELECT * FROM visa_detail_versions WHERE program_id = ? ORDER BY timestamp DESC').all(programId) as any[];
  return rows.map(r => ({
    id: r.id,
    programId: r.program_id,
    data: JSON.parse(r.data_json || '{}'),
    editorId: r.editor_id,
    timestamp: r.timestamp,
    changeReason: r.change_reason
  }));
}

export function saveVisaVersion(version: any) {
  const stmt = db.prepare(`
    INSERT INTO visa_detail_versions (id, program_id, data_json, editor_id, timestamp, change_reason)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(version.id, version.programId, JSON.stringify(version.data), version.editorId, version.timestamp, version.changeReason);
}

