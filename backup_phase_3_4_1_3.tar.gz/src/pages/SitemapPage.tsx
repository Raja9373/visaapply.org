import React, { useState } from 'react';
import { FULL_VISA_DB, BASE_COUNTRY_VISAS, COUNTRY_INFO, NAME_MAP_249, FLAG_MAP_249, VisaItem, CountryVisas } from '../data/fullVisaDatabase';
import { UK_111_VISAS } from '../data/ukVisas';
import {
  UK_GROUP_1_REGIONAL_WORK,
  UK_GROUP_2_FAMILY_SPECIAL,
  UK_GROUP_3_EUSS_ROUTES,
  UK_GROUP_4_BNO_ROUTES,
  UK_GROUP_5_UKRAINE_SCHEMES,
  UK_GROUP_6_PROTECTION_STATELESS,
  UK_GROUP_7_SETTLEMENT_ROUTES,
  UK_GROUP_8_NATIONALITY_CITIZENSHIP,
  UK_GROUP_9_ENTRY_STATUS,
  UK_GROUP_10_ARMED_FORCES,
  UK_GROUP_11_LEGACY_ROUTES
} from '../data/ukAdditionalRoutes';

export function SitemapPage({ navigate }: { navigate?: (path: string) => void }) {
  const [search, setSearch] = useState('');

  const countryCodes = Object.keys(NAME_MAP_249)
    .filter(code => code !== 'eu')
    .map(code => code.toUpperCase());

  const filteredCodes = countryCodes.filter(code => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    const lower = code.toLowerCase();
    const name = (NAME_MAP_249[lower] || COUNTRY_INFO[code]?.name || '').toLowerCase();
    return lower.includes(q) || name.includes(q);
  });

  const categoriesList: (keyof CountryVisas)[] = ['tourist', 'work', 'student', 'family', 'business', 'pr'];
  
  let totalUniqueRecords = 0;
  countryCodes.forEach(toCode => {
    const cData = BASE_COUNTRY_VISAS[toCode.toLowerCase()] || BASE_COUNTRY_VISAS[toCode] || FULL_VISA_DB[toCode];
    if (cData) {
      categoriesList.forEach(cat => {
        totalUniqueRecords += cData[cat]?.length || 0;
      });
    }
  });

  const ukAdditionalGroups = [
    { title: "1. Regional Work, Salary & Shortage Classifications (11)", items: UK_GROUP_1_REGIONAL_WORK },
    { title: "2. Family Circumstance & Breakdown Routes (6)", items: UK_GROUP_2_FAMILY_SPECIAL },
    { title: "3. EU Settlement Scheme (EUSS) Complete Routes (8)", items: UK_GROUP_3_EUSS_ROUTES },
    { title: "4. Hong Kong BN(O) Additional Routes (5)", items: UK_GROUP_4_BNO_ROUTES },
    { title: "5. Ukraine Schemes (6)", items: UK_GROUP_5_UKRAINE_SCHEMES },
    { title: "6. Protection, Asylum & Stateless Routes (8)", items: UK_GROUP_6_PROTECTION_STATELESS },
    { title: "7. Settlement & Indefinite Leave to Remain (ILR) Routes (11)", items: UK_GROUP_7_SETTLEMENT_ROUTES },
    { title: "8. British Nationality & Citizenship Registration Routes (13)", items: UK_GROUP_8_NATIONALITY_CITIZENSHIP },
    { title: "9. Permission to Enter, Electronic Status & Special Entry (13)", items: UK_GROUP_9_ENTRY_STATUS },
    { title: "10. Armed Forces & Dependants Routes (7)", items: UK_GROUP_10_ARMED_FORCES },
    { title: "11. Historical & Legacy UK Visa Classifications (23)", items: UK_GROUP_11_LEGACY_ROUTES },
  ];

  const buildVisaUrl = (fromCode: string, toCode: string, cat: string, v: VisaItem) => {
    if (/^in-to-/i.test(v.id)) {
      return `/${v.id.replace(/^in-to-/i, `${fromCode.toLowerCase()}-to-`)}`;
    }
    const prefixRegex = new RegExp(`^[a-z]{2,3}-to-${toCode.toLowerCase()}-${cat}-`, 'i');
    const shortId = v.id.replace(prefixRegex, '');
    return `/${fromCode.toLowerCase()}-to-${toCode.toLowerCase()}-${cat}-${shortId}`;
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8 font-sans">
      <div>
        <div className="flex items-center gap-2 text-xs text-slate-600 mb-2 font-medium">
          <button onClick={() => navigate?.('/')} className="hover:underline text-blue-700 cursor-pointer">Home</button>
          <span>&gt;</span>
          <span className="text-slate-900 font-bold">Global Visa Sitemap Index (77,806 Total Indexed Pages)</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mb-2">
          VisaApply.org - Global Sitemap Architecture (77,806 Pages Across 85 XML Sitemaps)
        </h1>
        <p className="text-slate-700 text-sm">
          Complete index of 249 Countries + 1,494 Category Pages + {totalUniqueRecords.toLocaleString()} Visa Detail Pages + 61,752 Bilateral Routes (70 XML Files) + 2,748 Blog &amp; Interview Guides using canonical <code className="font-mono font-bold">https://www.visaapply.org/</code> URLs.
        </p>
      </div>

      {/* XML Sitemap Index Directory Banner */}
      <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-emerald-700 text-white text-xs font-extrabold px-2.5 py-0.5 rounded-full">
                ✅ Master Sitemap Index Live (77,806 Pages)
              </span>
              <h2 className="text-sm sm:text-base font-extrabold text-emerald-950">
                sitemap-index.xml — 85 Sub-Sitemaps (https://www.visaapply.org/)
              </h2>
            </div>
            <p className="text-xs text-emerald-900">
              Master Index: <code className="bg-white px-2 py-0.5 rounded border border-emerald-200 font-mono font-bold">https://www.visaapply.org/sitemap-index.xml</code> (No GSC API, pure XML Sitemap indexing).
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            <a
              href="/sitemap-index.xml"
              target="_blank"
              rel="nofollow noopener noreferrer"
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition-colors"
            >
              Open /sitemap-index.xml ↗
            </a>
            <a
              href="/robots.txt"
              target="_blank"
              rel="nofollow noopener noreferrer"
              className="px-3.5 py-2 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-bold rounded-xl transition-colors"
            >
              View /robots.txt ↗
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-1">
          <a
            href="/sitemap-countries.xml"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="bg-white hover:bg-emerald-100/60 border border-emerald-200 rounded-xl p-3 transition-colors block"
          >
            <div className="text-xs font-extrabold text-[#0B3D91]">sitemap-countries.xml</div>
            <div className="text-lg font-black text-slate-900 mt-0.5">249 Pages</div>
            <div className="text-[11px] text-slate-600">All 249 ISO Destination Hubs</div>
          </a>
          <a
            href="/sitemap-categories.xml"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="bg-white hover:bg-emerald-100/60 border border-emerald-200 rounded-xl p-3 transition-colors block"
          >
            <div className="text-xs font-extrabold text-[#0B3D91]">sitemap-categories.xml</div>
            <div className="text-lg font-black text-slate-900 mt-0.5">1,514 Pages</div>
            <div className="text-[11px] text-slate-600">249 Countries × 6 Categories + Tools</div>
          </a>
          <a
            href="/sitemap-visas-1.xml"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="bg-white hover:bg-emerald-100/60 border border-emerald-200 rounded-xl p-3 transition-colors block"
          >
            <div className="text-xs font-extrabold text-[#0B3D91]">sitemap-visas-1..12.xml</div>
            <div className="text-lg font-black text-slate-900 mt-0.5">{totalUniqueRecords.toLocaleString()} Pages</div>
            <div className="text-[11px] text-slate-600">Split into 12 XML Files (Real Visas Only)</div>
          </a>
          <a
            href="/sitemap-routes-1.xml"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="bg-white hover:bg-emerald-100/60 border border-emerald-200 rounded-xl p-3 transition-colors block"
          >
            <div className="text-xs font-extrabold text-[#0B3D91]">sitemap-routes-1..70.xml</div>
            <div className="text-lg font-black text-slate-900 mt-0.5">61,752 Pages</div>
            <div className="text-[11px] text-slate-600">Split into 70 XML Files (249×248)</div>
          </a>
          <a
            href="/sitemap-blogs.xml"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="bg-white hover:bg-emerald-100/60 border border-emerald-200 rounded-xl p-3 transition-colors block"
          >
            <div className="text-xs font-extrabold text-[#0B3D91]">sitemap-blogs.xml</div>
            <div className="text-lg font-black text-slate-900 mt-0.5">2,748 Pages</div>
            <div className="text-[11px] text-slate-600">SEO Blogs &amp; Interview Guides</div>
          </a>
        </div>
      </div>

      {/* Free Consular Services & Tools Index */}
      <div className="bg-white border border-slate-200 p-5 sm:p-6 rounded-2xl shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-100 pb-3">
          <h2 className="text-lg font-extrabold text-slate-900">
            🛠️ Free Consular Services &amp; Visa Tools Directory (100% Free)
          </h2>
          <span className="bg-blue-50 text-[#0B3D91] text-xs font-black px-3 py-1 rounded-full">
            Public &amp; Indexable Tools
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {[
            { url: '/scholarship-finder', label: '🏆 Scholarship Finder (100% Free)', sub: '15 Fully Funded, Partial & Merit Scholarships + Deadline Calendar' },
            { url: '/work-permit-guide', label: '🛠️ Work Permit Guide', sub: '100% Free • Jobs Abroad with Visa Sponsorship (Gulf, Europe, CA, AU)' },
            { url: '/student-visa-university', label: '🎓 Student Visa + University Finder', sub: 'FREE • Compare 5 Universities, Tuition, IELTS & Post-Study Work' },
            { url: '/passport-seva-guide', label: '📘 Passport Seva Guide (India)', sub: 'FREE Guide • New Passport, Renewal, Tatkal & Checklist PDF' },
            { url: '/oci-pio-guide', label: '🇮🇳 OCI / PIO Card Guide for NRI', sub: 'FREE Guide • Lifetime India Visa ($275), Eligibility & Documents' },
            { url: '/sponsorship-finder', label: '💼 Visa Sponsorship Finder', sub: '100% Free • H1B, UK, Canada, Australia & Germany Sponsors' },
            { url: '/multi-country-planner', label: '🧭 Multi-Country Trip Visa Planner', sub: 'Check 2–5 Countries in 1 Min • Full Trip PDF' },
            { url: '/visa-map', label: '🗺️ Interactive Global Visa Map', sub: '249 Passports • Visa-Free, VOA & e-Visa Map' },
            { url: '/bank-statement-guide', label: '🏦 Bank Statement Guide for Visa', sub: 'Required Balance Calculator & Checklist PDF' },
            { url: '/travel-insurance-compare', label: '🛡️ Travel Insurance Compare', sub: '100% FREE Compare • Tata AIG, HDFC Ergo, Niva Bupa' },
            { url: '/esim-249', label: '📶 eSIM for 249 Countries', sub: 'FREE Compare • Airalo, Holafly, Nomad in USD & INR' },
            { url: '/forex-card-compare', label: '💳 Forex Card Compare (0% Markup)', sub: 'FREE Compare • Niyo Global, Wise, HDFC, BookMyForex' },
            { url: '/visa-rejection-appeal', label: '⚖️ Visa Rejection Appeal Guide', sub: '100% Free Check & Appeal Letter PDF' },
            { url: '/sop-generator', label: '🎓 Free SOP Generator for Student Visa', sub: '800-Word Official SOP PDF' },
            { url: '/visa-tracking', label: '🔍 Track Your Visa Application Status', sub: 'Official VFS, CEAC, TLS & IRCC Links' },
            { url: '/dummy-ticket', label: '✈️ Dummy Ticket (Flight & Hotel)', sub: 'Verifiable Reservation Guide & PDF' },
            { url: '/cover-letter-generator', label: '📄 Cover Letter Generator', sub: '100% Free Consular Cover Letter PDF' },
            { url: '/embassy-slot-alert', label: '🔔 Embassy Slot Alert', sub: 'Free Email Alert for USA & Schengen' },
            { url: '/photo-resizer', label: '📷 Visa Photo Resizer (300 DPI)', sub: '35x45mm & 2x2 Inch Biometric Tool' },
            { url: '/golden-visa', label: '👑 Golden Visa Directory (2026)', sub: 'Sovereign Residency by Investment' }
          ].map((tool) => (
            <a
              key={tool.url}
              href={tool.url}
              onClick={(e) => {
                if (navigate) {
                  e.preventDefault();
                  navigate(tool.url);
                }
              }}
              className="p-3.5 bg-slate-50 hover:bg-blue-50/60 border border-slate-200 rounded-xl transition-colors block"
            >
              <div className="font-extrabold text-[#0B3D91]">{tool.label}</div>
              <div className="text-[11px] text-slate-600 mt-0.5">{tool.sub}</div>
            </a>
          ))}
        </div>
      </div>

      <div className="bg-white border border-slate-200 p-4 sm:p-6 rounded-2xl shadow-xs">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search destination country (e.g. United Kingdom, GB, US, Canada, Australia)..."
          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"
        />
      </div>

      <div className="space-y-8">
        {filteredCodes.map(toCode => {
          const lowerCode = toCode.toLowerCase();
          const cName = NAME_MAP_249[lowerCode] || COUNTRY_INFO[toCode]?.name || toCode;
          const cFlag = FLAG_MAP_249[lowerCode] || COUNTRY_INFO[toCode]?.flag || '🌍';
          
          return (
            <div key={toCode} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-3">
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <span>{cFlag}</span>
                  <span>Visa & Immigration Guides for {cName} ({toCode})</span>
                </h2>
                {toCode === 'GB' && (
                  <span className="bg-indigo-600 text-white text-xs font-extrabold px-3 py-1 rounded-full">
                    🇬🇧 222 Total UK Records (111 Official Visas + 111 Additional Routes)
                  </span>
                )}
              </div>

              {/* Special 2-Directory Breakdown for United Kingdom (GB) */}
              {toCode === 'GB' && (
                <div className="space-y-6 bg-indigo-50/40 border border-indigo-200 rounded-2xl p-5">
                  <div>
                    <h3 className="text-base font-extrabold text-indigo-950 mb-1">
                      🛂 Directory 1: Official UK Visa & Immigration Documents (111 Entries)
                    </h3>
                    <p className="text-xs text-slate-600 mb-3">
                      Tourist (13) · Work (32) · Student (10) · Family (27) · Business (9) · PR & Settlement (20)
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {categoriesList.map(cat => {
                        const visas = UK_111_VISAS[cat] || [];
                        return (
                          <div key={`uk-dir1-${cat}`} className="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                            <h4 className="text-xs font-extrabold uppercase text-indigo-900 mb-2 flex justify-between">
                              <span>{cat} Visas</span>
                              <span className="bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">{visas.length}</span>
                            </h4>
                            <ul className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                              {visas.map(v => {
                                const url = buildVisaUrl('IN', 'GB', cat, v);
                                return (
                                  <li key={v.id} className="text-xs flex items-start justify-between gap-2 border-b border-slate-100 pb-1">
                                    <a
                                      href={url}
                                      onClick={(e) => { if (navigate) { e.preventDefault(); navigate(url); } }}
                                      className="text-blue-600 hover:underline font-medium"
                                    >
                                      {v.officialCode ? `[${v.officialCode}] ` : ''}{v.name}
                                    </a>
                                    <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded shrink-0">
                                      {v.record_type || 'VISA_ROUTE'}
                                    </span>
                                  </li>
                                );
                              })}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-indigo-200">
                    <h3 className="text-base font-extrabold text-purple-950 mb-1">
                      📋 Directory 2: Additional UK Routes, Schemes & Classifications (111 Entries)
                    </h3>
                    <p className="text-xs text-slate-600 mb-3">
                      Grouped across 11 statutory categories with record_type, application status, and official GOV.UK verification links.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {ukAdditionalGroups.map((grp, idx) => (
                        <div key={`uk-dir2-${idx}`} className="bg-white p-3.5 rounded-xl border border-purple-200 shadow-2xs">
                          <h4 className="text-xs font-extrabold text-purple-950 mb-2">{grp.title}</h4>
                          <ul className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                            {grp.items.map(v => {
                              const url = buildVisaUrl('IN', 'GB', v.category || 'pr', v);
                              return (
                                <li key={v.id} className="text-xs flex flex-col gap-0.5 border-b border-slate-100 pb-1.5">
                                  <div className="flex items-start justify-between gap-2">
                                    <a
                                      href={url}
                                      onClick={(e) => { if (navigate) { e.preventDefault(); navigate(url); } }}
                                      className="text-blue-700 hover:underline font-semibold"
                                    >
                                      [{v.officialCode}] {v.officialName || v.name}
                                    </a>
                                    <span className="text-[10px] font-mono bg-purple-100 text-purple-900 px-1.5 py-0.5 rounded shrink-0">
                                      {v.record_type}
                                    </span>
                                  </div>
                                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                                    <span>Status: <strong>{v.status || 'Active'}</strong> ({v.application_status || 'OPEN'})</span>
                                    {v.officialSource && (
                                      <a href={v.officialSource} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">
                                        GOV.UK ↗
                                      </a>
                                    )}
                                  </div>
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {/* Standard Country Matrix (Showing Primary Origin IN + Dual Access) */}
              {['IN', 'US', 'GB', 'CA', 'AU'].map(fromCode => {
                if (fromCode === toCode) return null;
                const countryData: CountryVisas = FULL_VISA_DB[fromCode]?.[toCode] || BASE_COUNTRY_VISAS[toCode];
                if (!countryData) return null;

                return (
                  <div key={`${fromCode}-to-${toCode}`} className="space-y-2">
                    <h3 className="text-sm font-semibold text-slate-700">From {COUNTRY_INFO[fromCode]?.name || fromCode} to {cName}:</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {categoriesList.map(cat => {
                        const visas = countryData[cat] || [];
                        if (visas.length === 0) return null;
                        return (
                          <div key={cat} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                            <h4 className="text-xs font-bold uppercase text-slate-500 mb-2 flex justify-between">
                              <span>{cat}</span>
                              <span>({visas.length})</span>
                            </h4>
                            <ul className="space-y-1 max-h-48 overflow-y-auto pr-1">
                              {visas.map(v => {
                                const url = buildVisaUrl(fromCode, toCode, cat, v);
                                return (
                                  <li key={v.id} className="text-xs">
                                    <a href={url} onClick={(e) => { if (navigate) { e.preventDefault(); navigate(url); } }} className="text-blue-600 hover:underline">
                                      {v.name}
                                    </a>
                                  </li>
                                );
                              })}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}


